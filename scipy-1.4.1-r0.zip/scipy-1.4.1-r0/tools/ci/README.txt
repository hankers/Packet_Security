Continuous integration support files
------------------------------------

