:orphan:

{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. autoattribute:: {{ objname }}