.. automodule:: scipy.io
   :no-members:
   :no-inherited-members:
   :no-special-members:
