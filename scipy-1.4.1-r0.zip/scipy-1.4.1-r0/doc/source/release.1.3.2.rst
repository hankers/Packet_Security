.. include:: ../release/1.3.2-notes.rst
